﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace CRUD_RTAS.Mapeamento
{
    internal class Local_soltura
    {
        public int Id_local_soltura {  get; set; }
        public string nome { get; set; }
        public string Bioma{ get; set; }
            
        public string Cidade { get; set;  }
        public string Estado { get; set;  }
    }
}
