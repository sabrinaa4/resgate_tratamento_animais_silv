﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CRUD_RTAS.Mapeamento
{
    internal class Recinto_voluntario
    {
        public int Id_recinto_voluntario {  get; set; }
        public Recinto Recinto { get; set; }//fk
        public Voluntario Voluntario { get; set; }//fk
    }
}
