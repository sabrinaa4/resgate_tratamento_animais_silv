﻿using Org.BouncyCastle.Asn1.Mozilla;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace CRUD_RTAS.Mapeamento
{
    internal class Animal
    {
        public int Id_animal {  get; set; }
        public string Nome { get; set; }
        //public enum Sexo {M, F, I} //ENUM
        //public enum Status
        //{
        //    [Description("Em tratamento")] EmTratamento,
        //    [Description("Em reabilitação")] EmReabilitacao,
        //    Solto,
        //    [Description("Cativeiro permanente")] CativeiroPermanente
        //} //ENUM

        //public enum Origem
        //{
        //    Resgate,
        //    [Description("Apreensão")] Apreensao,
        //    [Description("Entrega voluntária")] EntregaVoluntaria
        //} //ENUM
        public string Sexo {  get; set; }
        public string Status {  get; set; }
        public string Origem {  get; set; }
        public DateOnly DataEntrada { get; set; }
        public Especie Especie{ get; set; }
        public Recinto Recinto { get; set; }
    }
}
