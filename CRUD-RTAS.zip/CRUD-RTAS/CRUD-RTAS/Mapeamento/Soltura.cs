﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CRUD_RTAS.Mapeamento
{
    internal class Soltura
    {
        public int Id_soltura {  get; set; }
        public string Observacoes { get; set; }
        public DateOnly Data_soltura { get; set; }
        public Animal Animal { get; set; }//fk
        public Veterinario Veterinario { get; set; }//fk
        public Local_soltura Local_soltura { get; set; }

        }
}
