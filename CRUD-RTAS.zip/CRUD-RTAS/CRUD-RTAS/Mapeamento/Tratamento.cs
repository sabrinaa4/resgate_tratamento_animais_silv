﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CRUD_RTAS.Mapeamento
{
    internal class Tratamento
    {
        public int Id_tratamento { get; set;  }
        public string Descricao { get; set; }
        public string Medicamento { get; set; }
        public decimal Custo { get; set; }
        public DateOnly Data_inicio { get; set; }
        public DateOnly Data_fim { get; set; }
        public Animal Animal { get; set; }
        public Veterinario Veterinario { get; set; }
        //public int Id_animal { get; set; }
        //public int Id_veterinario { get; set; }
    }
}
