﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CRUD_RTAS.Mapeamento
{
    internal class Voluntario
    {
        public int Id_voluntario { get; set; }
        public string Nome { get; set; }
        public string Cpf { get; set; }
        public string Telefone { get; set; }
        public string Area_atuacao { get; set; }


        
    } 

     
} 
