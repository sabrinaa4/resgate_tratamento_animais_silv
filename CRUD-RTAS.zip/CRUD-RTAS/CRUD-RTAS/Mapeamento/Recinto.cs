﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CRUD_RTAS.Mapeamento
{
    internal class Recinto
    {
        public int Id_recinto {  get; set; }
        public string Tipo { get; set; }

        public int capacidade { get; set; }
        public string localizacao { get; set; }
    }
}
