﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace CRUD_RTAS.Mapeamento
{
    internal class Especie
    {
        public int Id_especie { get; set;  }
        public string Nome_popular { get; set; }
        public string Nome_cientifico { get; set; }
        public string Grau_ameaca { get; set; }
        //public enum GrauAmeaca
        //{
        //    [Description("Pouco preocupante")] PoucoPreocupante,
        //    [Description("Quase ameaçada")] QuaseAmeacada,
        //    [Description("Vulnerável")] Vulneravel,
        //    [Description("Em perigo")] EmPerigo,
        //    [Description("Criticamente em perigo")] CriticamenteEmPerigo,
        //    [Description("Dados insuficientes")] DadosInsuficientes
        //} // ENUM
    }
}
