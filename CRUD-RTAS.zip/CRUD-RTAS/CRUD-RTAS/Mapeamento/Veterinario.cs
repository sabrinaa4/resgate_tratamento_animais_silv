﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CRUD_RTAS.Mapeamento
{
    internal class Veterinario
    {
        public int Id_veterinario {  get; set; }
        public string Nome {  get; set; }
        public string Crmv { get; set; }
        public string Especialidade { get; set; }
        public string Telefone { get; set; }
    }
}
