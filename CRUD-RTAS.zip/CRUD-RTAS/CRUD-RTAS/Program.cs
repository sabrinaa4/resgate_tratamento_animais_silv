﻿using CRUD_RTAS.DAO;
using CRUD_RTAS.Mapeamento;

namespace CRUD_RTAS
{
    internal class Program
    {

        static RecintoDAO recintoDAO = new RecintoDAO();
        static VoluntarioDAO voluntarioDAO = new VoluntarioDAO();
        static Recinto_voluntarioDAO recinto_voluntarioDAO = new Recinto_voluntarioDAO();
        static EspecieDAO especieDAO = new EspecieDAO();
        static AnimalDAO animalDAO = new AnimalDAO();
        static VeterinarioDAO veterinarioDAO = new VeterinarioDAO();
        static TratamentoDAO tratamentoDAO = new TratamentoDAO();
        static Local_solturaDAO local_solturaDAO = new Local_solturaDAO();
        static SolturaDAO solturaDAO = new SolturaDAO();

        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            int opcao;
            do
            {
                
                Console.Clear();
                Console.WriteLine(" ==== SISTEMA RESGATE E TRATAMENTO DE ANIMAIS SILVESTRES ====\n");
                Console.WriteLine("1 - Recinto");
                Console.WriteLine("2 - Voluntário");
                Console.WriteLine("3 - Recinto x Voluntário");
                Console.WriteLine("4 - Espécie");
                Console.WriteLine("5 - Animal");
                Console.WriteLine("6 - Veterinário");
                Console.WriteLine("7 - Tratamento");
                Console.WriteLine("8 - Local de Soltura");
                Console.WriteLine("9 - Soltura");
                Console.WriteLine("0 - Sair");
                Console.Write("\nEscolha uma opção: ");
                opcao = Convert.ToInt32(Console.ReadLine());
                try
                {
                    switch (opcao)
                    {
                        case 1: MenuRecinto(); break;
                        case 2: MenuVoluntario(); break;
                        case 3: MenuRecinto_voluntario(); break;
                        case 4: MenuEspecie(); break;
                        case 5: MenuAnimal(); break;
                        case 6: MenuVeterinario(); break;
                        case 7: MenuTratamento(); break;
                        case 8: MenuLocal_soltura(); break;
                        case 9: MenuSoltura(); break;
                        case 0: Console.WriteLine("Encerrando o sistema..."); break;
                        default:
                            Console.WriteLine("Opção inválida!");
                            Console.ReadLine();
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("\nErro: " + ex.Message);
                }
            } while (opcao != 0);
        }

        // ===================== RECINTO =====================
        static void MenuRecinto()
        {
            int opcao;
            do
            {
                opcao = 0;
                Console.Clear();
                Console.WriteLine(" ==== RECINTO ====\n");
                Console.WriteLine("1 - Cadastrar Recinto");
                Console.WriteLine("2 - Listar Recintos");
                Console.WriteLine("3 - Buscar Recinto por ID");
                Console.WriteLine("4 - Atualizar Recinto");
                Console.WriteLine("5 - Excluir Recinto");
                Console.WriteLine("0 - Voltar");
                Console.Write("\nEscolha uma opção: ");

                try
                {
                    opcao = Convert.ToInt32(Console.ReadLine());

                    switch (opcao)
                    {
                        case 1:
                            {
                                Recinto novo = new Recinto();
                                Console.Write("Tipo do recinto (Quarentena, Viveiro, Tanque, Enfermaria): ");
                                novo.Tipo = Console.ReadLine();
                                Console.Write("Capacidade: ");
                                novo.capacidade = Convert.ToInt32(Console.ReadLine());
                                Console.Write("Localização: ");
                                novo.localizacao = Console.ReadLine();

                                recintoDAO.Cadastrar(novo);
                                Console.WriteLine("\nRecinto cadastrado(a) com sucesso!");
                                break;
                            }
                        case 2:
                            {
                                List<Recinto> lista = recintoDAO.ListarTodos();
                                if (lista.Count == 0)
                                    Console.WriteLine("Nenhum registro cadastrado.");

                                foreach (Recinto x in lista)
                                {
                                    Console.WriteLine("ID: " + x.Id_recinto +
                                    " | Tipo: " + x.Tipo +
                                    " | Capacidade: " + x.capacidade +
                                    " | Localização: " + x.localizacao);
                                }
                                break;
                            }
                        case 3:
                            {
                                Console.Write("ID: ");
                                int id = Convert.ToInt32(Console.ReadLine());

                                Recinto x = recintoDAO.BuscarID(id);
                                Console.WriteLine("ID: " + x.Id_recinto +
                                " | Tipo: " + x.Tipo +
                                " | Capacidade: " + x.capacidade +
                                " | Localização: " + x.localizacao);
                                break;
                            }
                        case 4:
                            {
                                Console.Write("ID que deseja atualizar: ");
                                int id = Convert.ToInt32(Console.ReadLine());

                                //confere se o registro existe antes de pedir os novos dados
                                recintoDAO.BuscarID(id);

                                Console.WriteLine("\nDigite os novos dados:");
                                Recinto atualizado = new Recinto();
                                atualizado.Id_recinto = id;
                                Console.Write("Tipo do recinto (Quarentena, Viveiro, Tanque, Enfermaria): ");
                                atualizado.Tipo = Console.ReadLine();
                                Console.Write("Capacidade: ");
                                atualizado.capacidade = Convert.ToInt32(Console.ReadLine());
                                Console.Write("Localização: ");
                                atualizado.localizacao = Console.ReadLine();

                                recintoDAO.Atualizar(atualizado);
                                Console.WriteLine("\nRecinto atualizado(a) com sucesso!");
                                break;
                            }
                        case 5:
                            {
                                Console.Write("ID que deseja excluir: ");
                                int id = Convert.ToInt32(Console.ReadLine());

                                Console.Write("Tem certeza que deseja excluir? (S/N): ");
                                string confirmacao = Console.ReadLine();

                                if (confirmacao == "S" || confirmacao == "s")
                                {
                                    recintoDAO.Delete(id);
                                    Console.WriteLine("\nRecinto excluído(a) com sucesso!");
                                }
                                else
                                {
                                    Console.WriteLine("Exclusão cancelada.");
                                }
                                break;
                            }
                        case 0:
                            break;
                        default:
                            Console.WriteLine("Opção inválida!");
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("\nErro: " + ex.Message);
                }

                if (opcao != 0)
                {
                    Console.WriteLine("\nPressione ENTER para continuar...");
                    Console.ReadLine();
                }
            } while (opcao != 0);
        }

        // ===================== VOLUNTÁRIO =====================
        static void MenuVoluntario()
        {
            int opcao;
            do
            {
                opcao = 0;
                Console.Clear();
                Console.WriteLine(" ==== VOLUNTÁRIO ====\n");
                Console.WriteLine("1 - Cadastrar Voluntário");
                Console.WriteLine("2 - Listar Voluntários");
                Console.WriteLine("3 - Buscar Voluntário por ID");
                Console.WriteLine("4 - Atualizar Voluntário");
                Console.WriteLine("5 - Excluir Voluntário");
                Console.WriteLine("0 - Voltar");
                Console.Write("\nEscolha uma opção: ");

                try
                {
                    opcao = Convert.ToInt32(Console.ReadLine());

                    switch (opcao)
                    {
                        case 1:
                            {
                                Voluntario novo = new Voluntario();
                                Console.Write("Nome: ");
                                novo.Nome = Console.ReadLine();
                                Console.Write("CPF: ");
                                novo.Cpf = Console.ReadLine();
                                Console.Write("Telefone: ");
                                novo.Telefone = Console.ReadLine();
                                Console.Write("Área de atuação (ENTER para deixar vazio): ");
                                novo.Area_atuacao = Console.ReadLine();

                                voluntarioDAO.Cadastrar(novo);
                                Console.WriteLine("\nVoluntário cadastrado(a) com sucesso!");
                                break;
                            }
                        case 2:
                            {
                                List<Voluntario> lista = voluntarioDAO.ListarTodos();
                                if (lista.Count == 0)
                                    Console.WriteLine("Nenhum registro cadastrado.");

                                foreach (Voluntario x in lista)
                                {
                                    Console.WriteLine("ID: " + x.Id_voluntario +
                                    " | Nome: " + x.Nome +
                                    " | CPF: " + x.Cpf +
                                    " | Telefone: " + x.Telefone +
                                    " | Área de atuação: " + x.Area_atuacao);
                                }
                                break;
                            }
                        case 3:
                            {
                                Console.Write("ID: ");
                                int id = Convert.ToInt32(Console.ReadLine());

                                Voluntario x = voluntarioDAO.BuscarID(id);
                                Console.WriteLine("ID: " + x.Id_voluntario +
                                " | Nome: " + x.Nome +
                                " | CPF: " + x.Cpf +
                                " | Telefone: " + x.Telefone +
                                " | Área de atuação: " + x.Area_atuacao);
                                break;
                            }
                        case 4:
                            {
                                Console.Write("ID que deseja atualizar: ");
                                int id = Convert.ToInt32(Console.ReadLine());

                                //confere se o registro existe antes de pedir os novos dados
                                voluntarioDAO.BuscarID(id);

                                Console.WriteLine("\nDigite os novos dados:");
                                Voluntario atualizado = new Voluntario();
                                atualizado.Id_voluntario = id;
                                Console.Write("Nome: ");
                                atualizado.Nome = Console.ReadLine();
                                Console.Write("CPF: ");
                                atualizado.Cpf = Console.ReadLine();
                                Console.Write("Telefone: ");
                                atualizado.Telefone = Console.ReadLine();
                                Console.Write("Área de atuação (ENTER para deixar vazio): ");
                                atualizado.Area_atuacao = Console.ReadLine();

                                voluntarioDAO.Atualizar(atualizado);
                                Console.WriteLine("\nVoluntário atualizado(a) com sucesso!");
                                break;
                            }
                        case 5:
                            {
                                Console.Write("ID que deseja excluir: ");
                                int id = Convert.ToInt32(Console.ReadLine());

                                Console.Write("Tem certeza que deseja excluir? (S/N): ");
                                string confirmacao = Console.ReadLine();

                                if (confirmacao == "S" || confirmacao == "s")
                                {
                                    voluntarioDAO.Delete(id);
                                    Console.WriteLine("\nVoluntário excluído(a) com sucesso!");
                                }
                                else
                                {
                                    Console.WriteLine("Exclusão cancelada.");
                                }
                                break;
                            }
                        case 0:
                            break;
                        default:
                            Console.WriteLine("Opção inválida!");
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("\nErro: " + ex.Message);
                }

                if (opcao != 0)
                {
                    Console.WriteLine("\nPressione ENTER para continuar...");
                    Console.ReadLine();
                }
            } while (opcao != 0);
        }

        // ===================== RECINTO X VOLUNTÁRIO =====================
        static void MenuRecinto_voluntario()
        {
            int opcao;
            do
            {
                opcao = 0;
                Console.Clear();
                Console.WriteLine(" ==== RECINTO X VOLUNTÁRIO ====\n");
                Console.WriteLine("1 - Cadastrar");
                Console.WriteLine("2 - Listar");
                Console.WriteLine("3 - Buscar por ID");
                Console.WriteLine("4 - Atualizar");
                Console.WriteLine("5 - Excluir");
                Console.WriteLine("0 - Voltar");
                Console.Write("\nEscolha uma opção: ");

                try
                {
                    opcao = Convert.ToInt32(Console.ReadLine());

                    switch (opcao)
                    {
                        case 1:
                            {
                                Recinto_voluntario novo = new Recinto_voluntario();
                                novo.Recinto = new Recinto();
                                Console.Write("ID do recinto: ");
                                novo.Recinto.Id_recinto = Convert.ToInt32(Console.ReadLine());
                                novo.Voluntario = new Voluntario();
                                Console.Write("ID do voluntário: ");
                                novo.Voluntario.Id_voluntario = Convert.ToInt32(Console.ReadLine());

                                recinto_voluntarioDAO.Cadastrar(novo);
                                Console.WriteLine("\nVínculo cadastrado(a) com sucesso!");
                                break;
                            }
                        case 2:
                            {
                                List<Recinto_voluntario> lista = recinto_voluntarioDAO.ListarTodos();
                                if (lista.Count == 0)
                                    Console.WriteLine("Nenhum registro cadastrado.");

                                foreach (Recinto_voluntario x in lista)
                                {
                                    Console.WriteLine("ID: " + x.Id_recinto_voluntario +
                                    " | Recinto (ID): " + x.Recinto.Id_recinto +
                                    " | Voluntário (ID): " + x.Voluntario.Id_voluntario);
                                }
                                break;
                            }
                        case 3:
                            {
                                Console.Write("ID: ");
                                int id = Convert.ToInt32(Console.ReadLine());

                                Recinto_voluntario x = recinto_voluntarioDAO.BuscarID(id);
                                Console.WriteLine("ID: " + x.Id_recinto_voluntario +
                                " | Recinto (ID): " + x.Recinto.Id_recinto +
                                " | Voluntário (ID): " + x.Voluntario.Id_voluntario);
                                break;
                            }
                        case 4:
                            {
                                Console.Write("ID que deseja atualizar: ");
                                int id = Convert.ToInt32(Console.ReadLine());

                                //confere se o registro existe antes de pedir os novos dados
                                recinto_voluntarioDAO.BuscarID(id);

                                Console.WriteLine("\nDigite os novos dados:");
                                Recinto_voluntario atualizado = new Recinto_voluntario();
                                atualizado.Id_recinto_voluntario = id;
                                atualizado.Recinto = new Recinto();
                                Console.Write("ID do recinto: ");
                                atualizado.Recinto.Id_recinto = Convert.ToInt32(Console.ReadLine());
                                atualizado.Voluntario = new Voluntario();
                                Console.Write("ID do voluntário: ");
                                atualizado.Voluntario.Id_voluntario = Convert.ToInt32(Console.ReadLine());

                                recinto_voluntarioDAO.Atualizar(atualizado);
                                Console.WriteLine("\nVínculo atualizado(a) com sucesso!");
                                break;
                            }
                        case 5:
                            {
                                Console.Write("ID que deseja excluir: ");
                                int id = Convert.ToInt32(Console.ReadLine());

                                Console.Write("Tem certeza que deseja excluir? (S/N): ");
                                string confirmacao = Console.ReadLine();

                                if (confirmacao == "S" || confirmacao == "s")
                                {
                                    recinto_voluntarioDAO.Delete(id);
                                    Console.WriteLine("\nVínculo excluído(a) com sucesso!");
                                }
                                else
                                {
                                    Console.WriteLine("Exclusão cancelada.");
                                }
                                break;
                            }
                        case 0:
                            break;
                        default:
                            Console.WriteLine("Opção inválida!");
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("\nErro: " + ex.Message);
                }

                if (opcao != 0)
                {
                    Console.WriteLine("\nPressione ENTER para continuar...");
                    Console.ReadLine();
                }
            } while (opcao != 0);
        }

        // ===================== ESPÉCIE =====================
        static void MenuEspecie()
        {
            int opcao;
            do
            {
                opcao = 0;
                Console.Clear();
                Console.WriteLine(" ==== ESPÉCIE ====\n");
                Console.WriteLine("1 - Cadastrar Espécie");
                Console.WriteLine("2 - Listar Espécies");
                Console.WriteLine("3 - Buscar Espécie por ID");
                Console.WriteLine("4 - Atualizar Espécie");
                Console.WriteLine("5 - Excluir Espécie");
                Console.WriteLine("0 - Voltar");
                Console.Write("\nEscolha uma opção: ");

                try
                {
                    opcao = Convert.ToInt32(Console.ReadLine());

                    switch (opcao)
                    {
                        case 1:
                            {
                                Especie novo = new Especie();
                                Console.Write("Nome popular: ");
                                novo.Nome_popular = Console.ReadLine();
                                Console.Write("Nome científico: ");
                                novo.Nome_cientifico = Console.ReadLine();
                                Console.Write("Grau de ameaça (Pouco Preocupante, Quase Ameacada, Vulneravel, em perigo, Criticamente em Perigo, Dados Insuficientes): ");
                                novo.Grau_ameaca = Console.ReadLine();

                                especieDAO.Cadastrar(novo);
                                Console.WriteLine("\nEspécie cadastrado(a) com sucesso!");
                                break;
                            }
                        case 2:
                            {
                                List<Especie> lista = especieDAO.ListarTodos();
                                if (lista.Count == 0)
                                    Console.WriteLine("Nenhum registro cadastrado.");

                                foreach (Especie x in lista)
                                {
                                    Console.WriteLine("ID: " + x.Id_especie +
                                    " | Nome popular: " + x.Nome_popular +
                                    " | Nome científico: " + x.Nome_cientifico +
                                    " | Grau de ameaça: " + x.Grau_ameaca);
                                }
                                break;
                            }
                        case 3:
                            {
                                Console.Write("ID: ");
                                int id = Convert.ToInt32(Console.ReadLine());

                                Especie x = especieDAO.BuscarID(id);
                                Console.WriteLine("ID: " + x.Id_especie +
                                " | Nome popular: " + x.Nome_popular +
                                " | Nome científico: " + x.Nome_cientifico +
                                " | Grau de ameaça: " + x.Grau_ameaca);
                                break;
                            }
                        case 4:
                            {
                                Console.Write("ID que deseja atualizar: ");
                                int id = Convert.ToInt32(Console.ReadLine());

                                //confere se o registro existe antes de pedir os novos dados
                                especieDAO.BuscarID(id);

                                Console.WriteLine("\nDigite os novos dados:");
                                Especie atualizado = new Especie();
                                atualizado.Id_especie = id;
                                Console.Write("Nome popular: ");
                                atualizado.Nome_popular = Console.ReadLine();
                                Console.Write("Nome científico: ");
                                atualizado.Nome_cientifico = Console.ReadLine();
                                Console.Write("Grau de ameaça (Pouco Preocupante, Quase Ameacada, Vulneravel, Em perigo, Criticamente em Perigo, Dados Insuficientes): ");
                                atualizado.Grau_ameaca = Console.ReadLine();

                                especieDAO.Atualizar(atualizado);
                                Console.WriteLine("\nEspécie atualizado(a) com sucesso!");
                                break;
                            }
                        case 5:
                            {
                                Console.Write("ID que deseja excluir: ");
                                int id = Convert.ToInt32(Console.ReadLine());

                                Console.Write("Tem certeza que deseja excluir? (S/N): ");
                                string confirmacao = Console.ReadLine();

                                if (confirmacao == "S" || confirmacao == "s")
                                {
                                    especieDAO.Delete(id);
                                    Console.WriteLine("\nEspécie excluído(a) com sucesso!");
                                }
                                else
                                {
                                    Console.WriteLine("Exclusão cancelada.");
                                }
                                break;
                            }
                        case 0:
                            break;
                        default:
                            Console.WriteLine("Opção inválida!");
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("\nErro: " + ex.Message);
                }

                if (opcao != 0)
                {
                    Console.WriteLine("\nPressione ENTER para continuar...");
                    Console.ReadLine();
                }
            } while (opcao != 0);
        }

        // ===================== ANIMAL =====================
        static void MenuAnimal()
        {
            int opcao;
            do
            {
                opcao = 0;
                Console.Clear();
                Console.WriteLine(" ==== ANIMAL ====\n");
                Console.WriteLine("1 - Cadastrar Animal");
                Console.WriteLine("2 - Listar Animais");
                Console.WriteLine("3 - Buscar Animal por ID");
                Console.WriteLine("4 - Atualizar Animal");
                Console.WriteLine("5 - Excluir Animal");
                Console.WriteLine("0 - Voltar");
                Console.Write("\nEscolha uma opção: ");

                try
                {
                    opcao = Convert.ToInt32(Console.ReadLine());

                    switch (opcao)
                    {
                        case 1:
                            {
                                Animal novo = new Animal();
                                Console.Write("Nome: ");
                                novo.Nome = Console.ReadLine();
                                Console.Write("Sexo (M, F, I): ");
                                novo.Sexo = Console.ReadLine();
                                Console.Write("Status (Em Tratamento, Em Reabilitacao, Solto, Cativeiro Permanente): ");
                                novo.Status = Console.ReadLine();
                                Console.Write("Origem (Resgate, Apreensao, Entrega Voluntaria): ");
                                novo.Origem = Console.ReadLine();
                                Console.Write("Data de entrada: ");
                                novo.DataEntrada = DateOnly.Parse(Console.ReadLine());
                                novo.Especie = new Especie();
                                Console.Write("ID da espécie: ");
                                novo.Especie.Id_especie = Convert.ToInt32(Console.ReadLine());
                                Console.Write("ID do recinto (0 = sem recinto): ");
                                int idRecinto = Convert.ToInt32(Console.ReadLine());
                                

                                animalDAO.Cadastrar(novo);
                                Console.WriteLine("\nAnimal cadastrado(a) com sucesso!");
                                break;
                            }
                        case 2:
                            {
                                List<Animal> lista = animalDAO.ListarTodos();
                                if (lista.Count == 0)
                                    Console.WriteLine("Nenhum registro cadastrado.");

                                foreach (Animal x in lista)
                                {
                                    Console.WriteLine("ID: " + x.Id_animal +
                                    " | Nome: " + x.Nome +
                                    " | Sexo: " + x.Sexo +
                                    " | Status: " + x.Status +
                                    " | Origem: " + x.Origem +
                                    " | Entrada: " + x.DataEntrada.ToString("dd/MM/yyyy") +
                                    " | Espécie (ID): " + x.Especie.Id_especie +
                                    " | Recinto (ID): " + (x.Recinto == null ? "sem recinto" : x.Recinto.Id_recinto.ToString()));
                                }
                                break;
                            }
                        case 3:
                            {
                                Console.Write("ID: ");
                                int id = Convert.ToInt32(Console.ReadLine());

                                Animal x = animalDAO.BuscarID(id);
                                Console.WriteLine("ID: " + x.Id_animal +
                                " | Nome: " + x.Nome +
                                " | Sexo: " + x.Sexo +
                                " | Status: " + x.Status +
                                " | Origem: " + x.Origem +
                                " | Entrada: " + x.DataEntrada.ToString("dd/MM/yyyy") +
                                " | Espécie (ID): " + x.Especie.Id_especie +
                                " | Recinto (ID): " + (x.Recinto == null ? "sem recinto" : x.Recinto.Id_recinto.ToString()));
                                break;
                            }
                        case 4:
                            {
                                Console.Write("ID que deseja atualizar: ");
                                int id = Convert.ToInt32(Console.ReadLine());

                                animalDAO.BuscarID(id);

                                Console.WriteLine("\nDigite os novos dados:");
                                Animal atualizado = new Animal();
                                atualizado.Id_animal = id;
                                Console.Write("Nome: ");
                                atualizado.Nome = Console.ReadLine();
                                Console.Write("Sexo (M, F, I): ");
                                atualizado.Sexo = Console.ReadLine();
                                Console.Write("Status (Em Tratamento, Em Reabilitacao, Solto, Cativeiro Permanente): ");
                                atualizado.Status = Console.ReadLine();
                                Console.Write("Origem (Resgate, Apreensao, Entrega Voluntaria): ");
                                atualizado.Origem = Console.ReadLine();
                                Console.Write("Data de entrada: ");
                                atualizado.DataEntrada = DateOnly.Parse(Console.ReadLine());
                                atualizado.Especie = new Especie();
                                Console.Write("ID da espécie: ");
                                atualizado.Especie.Id_especie = Convert.ToInt32(Console.ReadLine());
                                Console.Write("ID do recinto: ");
                                int idRecinto = Convert.ToInt32(Console.ReadLine());      

                                animalDAO.Atualizar(atualizado);
                                Console.WriteLine("\nAnimal atualizado(a) com sucesso!");
                                break;
                            }
                        case 5:
                            {
                                Console.Write("ID que deseja excluir: ");
                                int id = Convert.ToInt32(Console.ReadLine());

                                Console.Write("Tem certeza que deseja excluir? (S/N): ");
                                string confirmacao = Console.ReadLine();

                                if (confirmacao == "S" || confirmacao == "s")
                                {
                                    animalDAO.Delete(id);
                                    Console.WriteLine("\nAnimal excluído(a) com sucesso!");
                                }
                                else
                                {
                                    Console.WriteLine("Exclusão cancelada.");
                                }
                                break;
                            }
                        case 0:
                            break;
                        default:
                            Console.WriteLine("Opção inválida!");
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("\nErro: " + ex.Message);
                }

                if (opcao != 0)
                {
                    Console.WriteLine("\nPressione ENTER para continuar...");
                    Console.ReadLine();
                }
            } while (opcao != 0);
        }

        // ===================== VETERINÁRIO =====================
        static void MenuVeterinario()
        {
            int opcao;
            do
            {
                opcao = 0;
                Console.Clear();
                Console.WriteLine(" ==== VETERINÁRIO ====\n");
                Console.WriteLine("1 - Cadastrar Veterinário");
                Console.WriteLine("2 - Listar Veterinários");
                Console.WriteLine("3 - Buscar Veterinário por ID");
                Console.WriteLine("4 - Atualizar Veterinário");
                Console.WriteLine("5 - Excluir Veterinário");
                Console.WriteLine("0 - Voltar");
                Console.Write("\nEscolha uma opção: ");

                try
                {
                    opcao = Convert.ToInt32(Console.ReadLine());

                    switch (opcao)
                    {
                        case 1:
                            {
                                Veterinario novo = new Veterinario();
                                Console.Write("Nome: ");
                                novo.Nome = Console.ReadLine();
                                Console.Write("CRMV: ");
                                novo.Crmv = Console.ReadLine();
                                Console.Write("Especialidade: ");
                                novo.Especialidade = Console.ReadLine();
                                Console.Write("Telefone: ");
                                novo.Telefone = Console.ReadLine();

                                veterinarioDAO.Cadastrar(novo);
                                Console.WriteLine("\nVeterinário cadastrado(a) com sucesso!");
                                break;
                            }
                        case 2:
                            {
                                List<Veterinario> lista = veterinarioDAO.ListarTodos();
                                if (lista.Count == 0)
                                    Console.WriteLine("Nenhum registro cadastrado.");

                                foreach (Veterinario x in lista)
                                {
                                    Console.WriteLine("ID: " + x.Id_veterinario +
                                    " | Nome: " + x.Nome +
                                    " | CRMV: " + x.Crmv +
                                    " | Especialidade: " + x.Especialidade +
                                    " | Telefone: " + x.Telefone);
                                }
                                break;
                            }
                        case 3:
                            {
                                Console.Write("ID: ");
                                int id = Convert.ToInt32(Console.ReadLine());

                                Veterinario x = veterinarioDAO.BuscarID(id);
                                Console.WriteLine("ID: " + x.Id_veterinario +
                                " | Nome: " + x.Nome +
                                " | CRMV: " + x.Crmv +
                                " | Especialidade: " + x.Especialidade +
                                " | Telefone: " + x.Telefone);
                                break;
                            }
                        case 4:
                            {
                                Console.Write("ID que deseja atualizar: ");
                                int id = Convert.ToInt32(Console.ReadLine());
                                veterinarioDAO.BuscarID(id);

                                Console.WriteLine("\nDigite os novos dados:");
                                Veterinario atualizado = new Veterinario();
                                atualizado.Id_veterinario = id;
                                Console.Write("Nome: ");
                                atualizado.Nome = Console.ReadLine();
                                Console.Write("CRMV: ");
                                atualizado.Crmv = Console.ReadLine();
                                Console.Write("Especialidade: ");
                                atualizado.Especialidade = Console.ReadLine();
                                Console.Write("Telefone: ");
                                atualizado.Telefone = Console.ReadLine();

                                veterinarioDAO.Atualizar(atualizado);
                                Console.WriteLine("\nVeterinário atualizado(a) com sucesso!");
                                break;
                            }
                        case 5:
                            {
                                Console.Write("ID que deseja excluir: ");
                                int id = Convert.ToInt32(Console.ReadLine());

                                Console.Write("Tem certeza que deseja excluir? (S/N): ");
                                string confirmacao = Console.ReadLine();

                                if (confirmacao == "S" || confirmacao == "s")
                                {
                                    veterinarioDAO.Delete(id);
                                    Console.WriteLine("\nVeterinário excluído(a) com sucesso!");
                                }
                                else
                                {
                                    Console.WriteLine("Exclusão cancelada.");
                                }
                                break;
                            }
                        case 0:
                            break;
                        default:
                            Console.WriteLine("Opção inválida!");
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("\nErro: " + ex.Message);
                }

                if (opcao != 0)
                {
                    Console.WriteLine("\nPressione ENTER para continuar...");
                    Console.ReadLine();
                }
            } while (opcao != 0);
        }

        // ===================== TRATAMENTO =====================
        static void MenuTratamento()
        {
            int opcao;
            do
            {
                opcao = 0;
                Console.Clear();
                Console.WriteLine(" ==== TRATAMENTO ====\n");
                Console.WriteLine("1 - Cadastrar Tratamento");
                Console.WriteLine("2 - Listar Tratamentos");
                Console.WriteLine("3 - Buscar Tratamento por ID");
                Console.WriteLine("4 - Atualizar Tratamento");
                Console.WriteLine("5 - Excluir Tratamento");
                Console.WriteLine("0 - Voltar");
                Console.Write("\nEscolha uma opção: ");

                try
                {
                    opcao = Convert.ToInt32(Console.ReadLine());

                    switch (opcao)
                    {
                        case 1:
                            {
                                Tratamento novo = new Tratamento();
                                Console.Write("Descrição: ");
                                novo.Descricao = Console.ReadLine();
                                Console.Write("Medicamento: ");
                                novo.Medicamento = Console.ReadLine();
                                Console.Write("Custo: ");
                                novo.Custo = Convert.ToDecimal(Console.ReadLine());
                                Console.Write("Data de início: ");
                                novo.Data_inicio = DateOnly.Parse(Console.ReadLine());
                                Console.Write("Data de fim: ");
                                novo.Data_fim = DateOnly.Parse(Console.ReadLine());
                                novo.Animal = new Animal();
                                Console.Write("ID do animal: ");
                                novo.Animal.Id_animal = Convert.ToInt32(Console.ReadLine());
                                novo.Veterinario = new Veterinario();
                                Console.Write("ID do veterinário: ");
                                novo.Veterinario.Id_veterinario = Convert.ToInt32(Console.ReadLine());

                                tratamentoDAO.Cadastrar(novo);
                                Console.WriteLine("\nTratamento cadastrado(a) com sucesso!");
                                break;
                            }
                        case 2:
                            {
                                List<Tratamento> lista = tratamentoDAO.ListarTodos();
                                if (lista.Count == 0)
                                    Console.WriteLine("Nenhum registro cadastrado.");

                                foreach (Tratamento x in lista)
                                {
                                    Console.WriteLine("ID: " + x.Id_tratamento +
                                    " | Descrição: " + x.Descricao +
                                    " | Medicamento: " + x.Medicamento +
                                    " | Custo: " + x.Custo +
                                    " | Início: " + x.Data_inicio.ToString("dd/MM/yyyy") +
                                    " | Fim: " + (x.Data_fim.ToString("dd/MM/yyyy")) +
                                    " | Animal (ID): " + x.Animal.Id_animal +
                                    " | Veterinário (ID): " + x.Veterinario.Id_veterinario);
                                }
                                break;
                            }
                        case 3:
                            {
                                Console.Write("ID: ");
                                int id = Convert.ToInt32(Console.ReadLine());

                                Tratamento x = tratamentoDAO.BuscarID(id);
                                Console.WriteLine("ID: " + x.Id_tratamento +
                                " | Descrição: " + x.Descricao +
                                " | Medicamento: " + x.Medicamento +
                                " | Custo: " + x.Custo +
                                " | Início: " + x.Data_inicio.ToString("dd/MM/yyyy") +
                                " | Fim: " + (x.Data_fim.ToString("dd/MM/yyyy")) +
                                " | Animal (ID): " + x.Animal.Id_animal +
                                " | Veterinário (ID): " + x.Veterinario.Id_veterinario);
                                break;
                            }
                        case 4:
                            {
                                Console.Write("ID que deseja atualizar: ");
                                int id = Convert.ToInt32(Console.ReadLine());
                                tratamentoDAO.BuscarID(id);

                                Console.WriteLine("\nDigite os novos dados:");
                                Tratamento atualizado = new Tratamento();
                                atualizado.Id_tratamento = id;
                                Console.Write("Descrição: ");
                                atualizado.Descricao = Console.ReadLine();
                                Console.Write("Medicamento: ");
                                atualizado.Medicamento = Console.ReadLine();
                                Console.Write("Custo: ");
                                atualizado.Custo = Convert.ToDecimal(Console.ReadLine());
                                Console.Write("Data de início: ");
                                atualizado.Data_inicio = DateOnly.Parse(Console.ReadLine());
                                Console.Write("Data de fim: ");
                                atualizado.Data_fim = DateOnly.Parse(Console.ReadLine());
                                atualizado.Animal = new Animal();
                                Console.Write("ID do animal: ");
                                atualizado.Animal.Id_animal = Convert.ToInt32(Console.ReadLine());
                                atualizado.Veterinario = new Veterinario();
                                Console.Write("ID do veterinário: ");
                                atualizado.Veterinario.Id_veterinario = Convert.ToInt32(Console.ReadLine());

                                tratamentoDAO.Atualizar(atualizado);
                                Console.WriteLine("\nTratamento atualizado(a) com sucesso!");
                                break;
                            }
                        case 5:
                            {
                                Console.Write("ID que deseja excluir: ");
                                int id = Convert.ToInt32(Console.ReadLine());

                                Console.Write("Tem certeza que deseja excluir? (S/N): ");
                                string confirmacao = Console.ReadLine();

                                if (confirmacao == "S" || confirmacao == "s")
                                {
                                    tratamentoDAO.Delete(id);
                                    Console.WriteLine("\nTratamento excluído(a) com sucesso!");
                                }
                                else
                                {
                                    Console.WriteLine("Exclusão cancelada.");
                                }
                                break;
                            }
                        case 0:
                            break;
                        default:
                            Console.WriteLine("Opção inválida!");
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("\nErro: " + ex.Message);
                }

                if (opcao != 0)
                {
                    Console.WriteLine("\nPressione ENTER para continuar...");
                    Console.ReadLine();
                }
            } while (opcao != 0);
        }

        // ===================== LOCAL DE SOLTURA =====================
        static void MenuLocal_soltura()
        {
            int opcao;
            do
            {
                opcao = 0;
                Console.Clear();
                Console.WriteLine(" ==== LOCAL DE SOLTURA ====\n");
                Console.WriteLine("1 - Cadastrar Local de Soltura");
                Console.WriteLine("2 - Listar Locais de Soltura");
                Console.WriteLine("3 - Buscar Local de Soltura por ID");
                Console.WriteLine("4 - Atualizar Local de Soltura");
                Console.WriteLine("5 - Excluir Local de Soltura");
                Console.WriteLine("0 - Voltar");
                Console.Write("\nEscolha uma opção: ");

                try
                {
                    opcao = Convert.ToInt32(Console.ReadLine());

                    switch (opcao)
                    {
                        case 1:
                            {
                                Local_soltura novo = new Local_soltura();
                                Console.Write("Nome do local: ");
                                novo.nome = Console.ReadLine();
                                Console.Write("Bioma (Amazonia, Cerrado, Mata Atlantica, Caatinga, Pampa, Pantanal): ");
                                novo.Bioma = Console.ReadLine();
                                Console.Write("Cidade: ");
                                novo.Cidade = Console.ReadLine();
                                Console.Write("Estado: ");
                                novo.Estado = Console.ReadLine();

                                local_solturaDAO.Cadastrar(novo);
                                Console.WriteLine("\nLocal de Soltura cadastrado(a) com sucesso!");
                                break;
                            }
                        case 2:
                            {
                                List<Local_soltura> lista = local_solturaDAO.ListarTodos();
                                if (lista.Count == 0)
                                    Console.WriteLine("Nenhum registro cadastrado.");

                                foreach (Local_soltura x in lista)
                                {
                                    Console.WriteLine("ID: " + x.Id_local_soltura +
                                    " | Nome: " + x.nome +
                                    " | Bioma: " + x.Bioma +
                                    " | Cidade: " + x.Cidade +
                                    " | Estado: " + x.Estado);
                                }
                                break;
                            }
                        case 3:
                            {
                                Console.Write("ID: ");
                                int id = Convert.ToInt32(Console.ReadLine());

                                Local_soltura x = local_solturaDAO.BuscarID(id);
                                Console.WriteLine("ID: " + x.Id_local_soltura +
                                " | Nome: " + x.nome +
                                " | Bioma: " + x.Bioma +
                                " | Cidade: " + x.Cidade +
                                " | Estado: " + x.Estado);
                                break;
                            }
                        case 4:
                            {
                                Console.Write("ID que deseja atualizar: ");
                                int id = Convert.ToInt32(Console.ReadLine());
                                local_solturaDAO.BuscarID(id);

                                Console.WriteLine("\nDigite os novos dados:");
                                Local_soltura atualizado = new Local_soltura();
                                atualizado.Id_local_soltura = id;
                                Console.Write("Nome do local: ");
                                atualizado.nome = Console.ReadLine();
                                Console.Write("Bioma (Amazonia, Cerrado, Mata Atlantica, Caatinga, Pampa, Pantanal): ");
                                atualizado.Bioma = Console.ReadLine();
                                Console.Write("Cidade: ");
                                atualizado.Cidade = Console.ReadLine();
                                Console.Write("Estado: ");
                                atualizado.Estado = Console.ReadLine();

                                local_solturaDAO.Atualizar(atualizado);
                                Console.WriteLine("\nLocal de Soltura atualizado(a) com sucesso!");
                                break;
                            }
                        case 5:
                            {
                                Console.Write("ID que deseja excluir: ");
                                int id = Convert.ToInt32(Console.ReadLine());

                                Console.Write("Tem certeza que deseja excluir? (S/N): ");
                                string confirmacao = Console.ReadLine();

                                if (confirmacao == "S" || confirmacao == "s")
                                {
                                    local_solturaDAO.Delete(id);
                                    Console.WriteLine("\nLocal de Soltura excluído(a) com sucesso!");
                                }
                                else
                                {
                                    Console.WriteLine("Exclusão cancelada.");
                                }
                                break;
                            }
                        case 0:
                            break;
                        default:
                            Console.WriteLine("Opção inválida!");
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("\nErro: " + ex.Message);
                }

                if (opcao != 0)
                {
                    Console.WriteLine("\nPressione ENTER para continuar...");
                    Console.ReadLine();
                }
            } while (opcao != 0);
        }

        // ===================== SOLTURA =====================
        static void MenuSoltura()
        {
            int opcao;
            do
            {
                opcao = 0;
                Console.Clear();
                Console.WriteLine(" ==== SOLTURA ====\n");
                Console.WriteLine("1 - Cadastrar Soltura");
                Console.WriteLine("2 - Listar Solturas");
                Console.WriteLine("3 - Buscar Soltura por ID");
                Console.WriteLine("4 - Atualizar Soltura");
                Console.WriteLine("5 - Excluir Soltura");
                Console.WriteLine("0 - Voltar");
                Console.Write("\nEscolha uma opção: ");

                try
                {
                    opcao = Convert.ToInt32(Console.ReadLine());

                    switch (opcao)
                    {
                        case 1:
                            {
                                Soltura novo = new Soltura();
                                Console.Write("Observações: ");
                                novo.Observacoes = Console.ReadLine();
                                Console.Write("Data da soltura: ");
                                novo.Data_soltura = DateOnly.Parse(Console.ReadLine());
                                novo.Animal = new Animal();
                                Console.Write("ID do animal: ");
                                novo.Animal.Id_animal = Convert.ToInt32(Console.ReadLine());
                                novo.Veterinario = new Veterinario();
                                Console.Write("ID do veterinário que autorizou: ");
                                novo.Veterinario.Id_veterinario = Convert.ToInt32(Console.ReadLine());
                                novo.Local_soltura = new Local_soltura();
                                Console.Write("ID do local de soltura: ");
                                novo.Local_soltura.Id_local_soltura = Convert.ToInt32(Console.ReadLine());

                                solturaDAO.Cadastrar(novo);
                                Console.WriteLine("\nSoltura cadastrado(a) com sucesso!");
                                break;
                            }
                        case 2:
                            {
                                List<Soltura> lista = solturaDAO.ListarTodos();
                                if (lista.Count == 0)
                                    Console.WriteLine("Nenhum registro cadastrado.");

                                foreach (Soltura x in lista)
                                {
                                    Console.WriteLine("ID: " + x.Id_soltura +
                                    " | Observações: " + x.Observacoes +
                                    " | Data: " + x.Data_soltura.ToString("dd/MM/yyyy") +
                                    " | Animal (ID): " + x.Animal.Id_animal +
                                    " | Veterinário (ID): " + x.Veterinario.Id_veterinario +
                                    " | Local (ID): " + x.Local_soltura.Id_local_soltura);
                                }
                                break;
                            }
                        case 3:
                            {
                                Console.Write("ID: ");
                                int id = Convert.ToInt32(Console.ReadLine());

                                Soltura x = solturaDAO.BuscarID(id);
                                Console.WriteLine("ID: " + x.Id_soltura +
                                " | Observações: " + x.Observacoes +
                                " | Data: " + x.Data_soltura.ToString("dd/MM/yyyy") +
                                " | Animal (ID): " + x.Animal.Id_animal +
                                " | Veterinário (ID): " + x.Veterinario.Id_veterinario +
                                " | Local (ID): " + x.Local_soltura.Id_local_soltura);
                                break;
                            }
                        case 4:
                            {
                                Console.Write("ID que deseja atualizar: ");
                                int id = Convert.ToInt32(Console.ReadLine());
                                solturaDAO.BuscarID(id);

                                Console.WriteLine("\nDigite os novos dados:");
                                Soltura atualizado = new Soltura();
                                atualizado.Id_soltura = id;
                                Console.Write("Observações: ");
                                atualizado.Observacoes = Console.ReadLine();
                                Console.Write("Data da soltura: ");
                                atualizado.Data_soltura = DateOnly.Parse(Console.ReadLine());
                                atualizado.Animal = new Animal();
                                Console.Write("ID do animal: ");
                                atualizado.Animal.Id_animal = Convert.ToInt32(Console.ReadLine());
                                atualizado.Veterinario = new Veterinario();
                                Console.Write("ID do veterinário que autorizou: ");
                                atualizado.Veterinario.Id_veterinario = Convert.ToInt32(Console.ReadLine());
                                atualizado.Local_soltura = new Local_soltura();
                                Console.Write("ID do local de soltura: ");
                                atualizado.Local_soltura.Id_local_soltura = Convert.ToInt32(Console.ReadLine());

                                solturaDAO.Atualizar(atualizado);
                                Console.WriteLine("\nSoltura atualizado(a) com sucesso!");
                                break;
                            }
                        case 5:
                            {
                                Console.Write("ID que deseja excluir: ");
                                int id = Convert.ToInt32(Console.ReadLine());

                                Console.Write("Tem certeza que deseja excluir? (S/N): ");
                                string confirmacao = Console.ReadLine();

                                if (confirmacao == "S" || confirmacao == "s")
                                {
                                    solturaDAO.Delete(id);
                                    Console.WriteLine("\nSoltura excluído(a) com sucesso!");
                                }
                                else
                                {
                                    Console.WriteLine("Exclusão cancelada.");
                                }
                                break;
                            }
                        case 0:
                            break;
                        default:
                            Console.WriteLine("Opção inválida!");
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("\nErro: " + ex.Message);
                }

                if (opcao != 0)
                {
                    Console.WriteLine("\nPressione ENTER para continuar...");
                    Console.ReadLine();
                }
            } while (opcao != 0);
        }

    }
}
