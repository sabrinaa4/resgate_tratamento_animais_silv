﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CRUD_RTAS.Interface
{
    internal interface IDAO <T>
    {
        void Cadastrar(T t);
        void Atualizar(T t);
        void Delete(int t);
        List<T> ListarTodos();
        T BuscarID(int t);
    }
}
