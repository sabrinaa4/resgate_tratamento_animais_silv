﻿using CRUD_RTAS.DataBase;
using CRUD_RTAS.Interface;
using CRUD_RTAS.Mapeamento;
using MySql.Data.MySqlClient;

namespace CRUD_RTAS.DAO
{
    internal class EspecieDAO : IDAO<Especie>
    {
        public void Cadastrar(Especie especie)
        {
            try
            {
                string sql = @"INSERT INTO especie (nome_popular, nome_cientifico, grau_ameaca) VALUES
                (@nome_popular, @nome_cientifico, @grau_ameaca)";
                using (var conexao = Conexao.Conectar())
                using (var cmd = new MySqlCommand(sql, conexao))
                {
                    cmd.Parameters.AddWithValue("@nome_popular", especie.Nome_popular);
                    cmd.Parameters.AddWithValue("@nome_cientifico", especie.Nome_cientifico);
                    cmd.Parameters.AddWithValue("@grau_ameaca", especie.Grau_ameaca);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void Atualizar(Especie especie)
        {
            try
            {
                string sql = @"UPDATE especie SET nome_popular = @nome_popular, nome_cientifico = @nome_cientifico,
                grau_ameaca = @grau_ameaca WHERE id_especie = @id_especie";
                using (var conexao = Conexao.Conectar())
                using (var cmd = new MySqlCommand(sql, conexao))
                {
                    cmd.Parameters.AddWithValue("@nome_popular", especie.Nome_popular);
                    cmd.Parameters.AddWithValue("@nome_cientifico", especie.Nome_cientifico);
                    cmd.Parameters.AddWithValue("@grau_ameaca", especie.Grau_ameaca.ToString());
                    cmd.Parameters.AddWithValue("@id_especie", especie.Id_especie);
                    var linhas = cmd.ExecuteNonQuery();

                    if (linhas == 0)
                        throw new Exception("Nenhum registro foi atualizado (verifique o id_especie)");
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void Delete(int id_especie)
        {
            try
            {
                string sql = "DELETE FROM especie WHERE id_especie = @id_especie";
                using (var conexao = Conexao.Conectar())
                using (var cmd = new MySqlCommand(sql, conexao))
                {
                    cmd.Parameters.AddWithValue("@id_especie", id_especie);
                    var linhasAfetadas = cmd.ExecuteNonQuery();
                    if (linhasAfetadas == 0)
                        throw new Exception("Nenhum registro encontrado com esse ID.");
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public List<Especie> ListarTodos()
        {
            List<Especie> especie = new List<Especie>();

            try
            {
                string sql = "SELECT * FROM especie ORDER BY nome_popular";

                using (var conexao = Conexao.Conectar())
                using (var comando = new MySqlCommand(sql, conexao))
                using (MySqlDataReader dr = comando.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        Especie especies = new Especie()
                        {
                            Id_especie = Convert.ToInt32(dr["id_especie"]),
                            Nome_popular = dr["nome_popular"].ToString(),
                            Nome_cientifico = dr["nome_cientifico"].ToString(),
                            Grau_ameaca = (dr["grau_ameaca"].ToString())
                        };
                        especie.Add(especies);
                    }
                }

                return especie;
            }
            catch (Exception ex)
            {
                throw new Exception("Erro ao listar as espécies: " + ex.Message);
            }
        }

        public Especie BuscarID(int id_especie)
        {
            try
            {
                string sql = "SELECT * FROM especie WHERE id_especie = @id_especie";

                using (var conexao = Conexao.Conectar())
                using (var cmd = new MySqlCommand(sql, conexao))
                {
                    cmd.Parameters.AddWithValue("@id_especie", id_especie);

                    using (MySqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.Read())
                        {
                            Especie especie = new Especie();

                            especie.Id_especie = Convert.ToInt32(dr["id_especie"]);
                            especie.Nome_popular = dr["nome_popular"].ToString();
                            especie.Nome_cientifico = dr["nome_cientifico"].ToString();
                            especie.Grau_ameaca = (dr["grau_ameaca"].ToString());

                            return especie;
                        }
                        else
                        {
                            throw new Exception("Nenhuma espécie encontrada com esse ID.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
