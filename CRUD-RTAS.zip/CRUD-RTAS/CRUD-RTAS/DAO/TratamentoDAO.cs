﻿using CRUD_RTAS.DataBase;
using CRUD_RTAS.Interface;
using CRUD_RTAS.Mapeamento;
using MySql.Data.MySqlClient;

namespace CRUD_RTAS.DAO
{
    internal class TratamentoDAO : IDAO<Tratamento>
    {
        public void Cadastrar(Tratamento tratamento)
        {
            try
            {
                string sql = @"INSERT INTO tratamento (descricao, medicamento, custo, data_inicio, data_fim, id_animal_fk, id_veterinario_fk) VALUES
                (@descricao, @medicamento, @custo, @data_inicio, @data_fim, @id_animal_fk, @id_veterinario_fk)";
                using (var conexao = Conexao.Conectar())
                using (var cmd = new MySqlCommand(sql, conexao))
                {
                    cmd.Parameters.AddWithValue("@descricao", tratamento.Descricao);
                    cmd.Parameters.AddWithValue("@medicamento", tratamento.Medicamento);
                    cmd.Parameters.AddWithValue("@custo", tratamento.Custo);
                    cmd.Parameters.Add("@data_inicio", MySqlDbType.Date).Value = tratamento.Data_inicio.ToDateTime(TimeOnly.MinValue);
                    cmd.Parameters.Add("@data_fim", MySqlDbType.Date).Value = tratamento.Data_fim.ToDateTime(TimeOnly.MinValue);
                    cmd.Parameters.AddWithValue("@id_animal_fk", tratamento.Animal.Id_animal);
                    cmd.Parameters.AddWithValue("@id_veterinario_fk", tratamento.Veterinario.Id_veterinario);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void Atualizar(Tratamento tratamento)
        {
            try
            {
                string sql = @"UPDATE tratamento SET descricao = @descricao, medicamento = @medicamento, custo = @custo,
                data_inicio = @data_inicio, data_fim = @data_fim, id_animal_fk = @id_animal_fk,
                id_veterinario_fk = @id_veterinario_fk WHERE id_tratamento = @id_tratamento";
                using (var conexao = Conexao.Conectar())
                using (var cmd = new MySqlCommand(sql, conexao))
                {
                    cmd.Parameters.AddWithValue("@descricao", tratamento.Descricao);
                    cmd.Parameters.AddWithValue("@medicamento", tratamento.Medicamento);
                    cmd.Parameters.AddWithValue("@custo", tratamento.Custo);
                    cmd.Parameters.Add("@data_inicio", MySqlDbType.Date).Value = tratamento.Data_inicio.ToDateTime(TimeOnly.MinValue);
                    cmd.Parameters.Add("@data_fim", MySqlDbType.Date).Value = tratamento.Data_fim.ToDateTime(TimeOnly.MinValue);
                    cmd.Parameters.AddWithValue("@id_animal_fk", tratamento.Animal.Id_animal);
                    cmd.Parameters.AddWithValue("@id_veterinario_fk", tratamento.Veterinario.Id_veterinario);
                    cmd.Parameters.AddWithValue("@id_tratamento", tratamento.Id_tratamento);
                    var linhas = cmd.ExecuteNonQuery();

                    if (linhas == 0)
                        throw new Exception("Nenhum registro foi atualizado (verifique o id_tratamento)");
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void Delete(int id_tratamento)
        {
            try
            {
                string sql = "DELETE FROM tratamento WHERE id_tratamento = @id_tratamento";
                using (var conexao = Conexao.Conectar())
                using (var cmd = new MySqlCommand(sql, conexao))
                {
                    cmd.Parameters.AddWithValue("@id_tratamento", id_tratamento);
                    var linhasAfetadas = cmd.ExecuteNonQuery();
                    if (linhasAfetadas == 0)
                        throw new Exception("Nenhum registro encontrado com esse ID.");
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public List<Tratamento> ListarTodos()
        {
            List<Tratamento> tratamento = new List<Tratamento>();

            try
            {
                string sql = "SELECT * FROM tratamento ORDER BY data_inicio DESC";

                using (var conexao = Conexao.Conectar())
                using (var comando = new MySqlCommand(sql, conexao))
                using (MySqlDataReader dr = comando.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        Tratamento tratamentos = new Tratamento()
                        {
                            Id_tratamento = Convert.ToInt32(dr["id_tratamento"]),
                            Descricao = dr["descricao"].ToString(),
                            Medicamento = dr["medicamento"].ToString(),
                            Custo = Convert.ToDecimal(dr["custo"]),
                            Data_inicio = DateOnly.FromDateTime(Convert.ToDateTime(dr["data_inicio"])),
                            Data_fim = DateOnly.FromDateTime(Convert.ToDateTime(dr["data_fim"])),
                            Animal = new Animal() { Id_animal = Convert.ToInt32(dr["id_animal_fk"]) },
                            Veterinario = new Veterinario() { Id_veterinario = Convert.ToInt32(dr["id_veterinario_fk"]) }

                        };
                        tratamento.Add(tratamentos);
                    }
                }

                return tratamento;
            }
            catch (Exception ex)
            {
                throw new Exception("Erro ao listar os tratamentos: " + ex.Message);
            }
        }

        public Tratamento BuscarID(int id_tratamento)
        {
            try
            {
                string sql = "SELECT * FROM tratamento WHERE id_tratamento = @id_tratamento";

                using (var conexao = Conexao.Conectar())
                using (var cmd = new MySqlCommand(sql, conexao))
                {
                    cmd.Parameters.AddWithValue("@id_tratamento", id_tratamento);

                    using (MySqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.Read())
                        {
                            Tratamento tratamento = new Tratamento();

                            tratamento.Id_tratamento = Convert.ToInt32(dr["id_tratamento"]);
                            tratamento.Descricao = dr["descricao"].ToString();
                            tratamento.Medicamento = dr["medicamento"].ToString();
                            tratamento.Custo = Convert.ToDecimal(dr["custo"]);
                            tratamento.Data_inicio = DateOnly.FromDateTime(Convert.ToDateTime(dr["data_inicio"]));
                            tratamento.Data_fim = DateOnly.FromDateTime(Convert.ToDateTime(dr["data_fim"]));
                            tratamento.Animal = new Animal() { Id_animal = Convert.ToInt32(dr["id_animal_fk"]) };
                            tratamento.Veterinario = new Veterinario() { Id_veterinario = Convert.ToInt32(dr["id_veterinario_fk"]) };

                            return tratamento;
                        }
                        else
                        {
                            throw new Exception("Nenhum tratamento encontrado com esse ID.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
