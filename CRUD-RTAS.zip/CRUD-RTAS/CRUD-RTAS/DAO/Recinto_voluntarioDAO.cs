﻿using CRUD_RTAS.DataBase;
using CRUD_RTAS.Interface;
using CRUD_RTAS.Mapeamento;
using MySql.Data.MySqlClient;

namespace CRUD_RTAS.DAO
{
    internal class Recinto_voluntarioDAO : IDAO<Recinto_voluntario>
    {
        public void Cadastrar(Recinto_voluntario recinto_voluntario)
        {
            try
            {
                string sql = @"INSERT INTO recinto_voluntario (id_recinto_fk, id_voluntario_fk) VALUES
                (@id_recinto_fk, @id_voluntario_fk)";
                using (var conexao = Conexao.Conectar())
                using (var cmd = new MySqlCommand(sql, conexao))
                {
                    cmd.Parameters.AddWithValue("@id_recinto_fk", recinto_voluntario.Recinto.Id_recinto);
                    cmd.Parameters.AddWithValue("@id_voluntario_fk", recinto_voluntario.Voluntario.Id_voluntario);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void Atualizar(Recinto_voluntario recinto_voluntario)
        {
            try
            {
                string sql = @"UPDATE recinto_voluntario SET id_recinto_fk = @id_recinto_fk,
                id_voluntario_fk = @id_voluntario_fk WHERE id_recinto_voluntario = @id_recinto_voluntario";
                using (var conexao = Conexao.Conectar())
                using (var cmd = new MySqlCommand(sql, conexao))
                {
                    cmd.Parameters.AddWithValue("@id_recinto_fk", recinto_voluntario.Recinto.Id_recinto);
                    cmd.Parameters.AddWithValue("@id_voluntario_fk", recinto_voluntario.Voluntario.Id_voluntario);
                    cmd.Parameters.AddWithValue("@id_recinto_voluntario", recinto_voluntario.Id_recinto_voluntario);
                    var linhas = cmd.ExecuteNonQuery();

                    if (linhas == 0)
                        throw new Exception("Nenhum registro foi atualizado (verifique o id_recinto_voluntario)");
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void Delete(int id_recinto_voluntario)
        {
            try
            {
                string sql = "DELETE FROM recinto_voluntario WHERE id_recinto_voluntario = @id_recinto_voluntario";
                using (var conexao = Conexao.Conectar())
                using (var cmd = new MySqlCommand(sql, conexao))
                {
                    cmd.Parameters.AddWithValue("@id_recinto_voluntario", id_recinto_voluntario);
                    var linhasAfetadas = cmd.ExecuteNonQuery();
                    if (linhasAfetadas == 0)
                        throw new Exception("Nenhum registro encontrado com esse ID.");
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public List<Recinto_voluntario> ListarTodos()
        {
            List<Recinto_voluntario> recinto_voluntario = new List<Recinto_voluntario>();

            try
            {
                string sql = "SELECT * FROM recinto_voluntario ORDER BY id_recinto_voluntario";

                using (var conexao = Conexao.Conectar())
                using (var comando = new MySqlCommand(sql, conexao))
                using (MySqlDataReader dr = comando.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        Recinto_voluntario vinculos = new Recinto_voluntario()
                        {
                            Id_recinto_voluntario = Convert.ToInt32(dr["id_recinto_voluntario"]),
                            Recinto = new Recinto() { Id_recinto = Convert.ToInt32(dr["id_recinto_fk"]) },
                            Voluntario = new Voluntario() { Id_voluntario = Convert.ToInt32(dr["id_voluntario_fk"]) }
                        };
                        recinto_voluntario.Add(vinculos);
                    }
                }

                return recinto_voluntario;
            }
            catch (Exception ex)
            {
                throw new Exception("Erro ao listar os vínculos entre recintos e voluntários: " + ex.Message);
            }
        }

        public Recinto_voluntario BuscarID(int id_recinto_voluntario)
        {
            try
            {
                string sql = "SELECT * FROM recinto_voluntario WHERE id_recinto_voluntario = @id_recinto_voluntario";

                using (var conexao = Conexao.Conectar())
                using (var cmd = new MySqlCommand(sql, conexao))
                {
                    cmd.Parameters.AddWithValue("@id_recinto_voluntario", id_recinto_voluntario);

                    using (MySqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.Read())
                        {
                            Recinto_voluntario recinto_voluntario = new Recinto_voluntario();

                            recinto_voluntario.Id_recinto_voluntario = Convert.ToInt32(dr["id_recinto_voluntario"]);
                            recinto_voluntario.Recinto = new Recinto() { Id_recinto = Convert.ToInt32(dr["id_recinto_fk"]) };
                            recinto_voluntario.Voluntario = new Voluntario() { Id_voluntario = Convert.ToInt32(dr["id_voluntario_fk"]) };

                            return recinto_voluntario;
                        }
                        else
                        {
                            throw new Exception("Nenhum vínculo encontrado com esse ID.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
