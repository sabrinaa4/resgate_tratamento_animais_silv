﻿using CRUD_RTAS.DataBase;
using CRUD_RTAS.Interface;
using CRUD_RTAS.Mapeamento;
using MySql.Data.MySqlClient;

namespace CRUD_RTAS.DAO
{
    internal class RecintoDAO : IDAO<Recinto>
    {
        public void Cadastrar(Recinto recinto)
        {
            try
            {
                string sql = @"INSERT INTO recinto (tipo, capacidade, localizacao) VALUES
                (@tipo, @capacidade, @localizacao)";
                using (var conexao = Conexao.Conectar())
                using (var cmd = new MySqlCommand(sql, conexao))
                {
                    cmd.Parameters.AddWithValue("@tipo", recinto.Tipo);
                    cmd.Parameters.AddWithValue("@capacidade", recinto.capacidade);
                    cmd.Parameters.AddWithValue("@localizacao", recinto.localizacao);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void Atualizar(Recinto recinto)
        {
            try
            {
                string sql = @"UPDATE recinto SET tipo = @tipo, capacidade = @capacidade,
                localizacao = @localizacao WHERE id_recinto = @id_recinto";
                using (var conexao = Conexao.Conectar())
                using (var cmd = new MySqlCommand(sql, conexao))
                {
                    cmd.Parameters.AddWithValue("@tipo", recinto.Tipo);
                    cmd.Parameters.AddWithValue("@capacidade", recinto.capacidade);
                    cmd.Parameters.AddWithValue("@localizacao", recinto.localizacao);
                    cmd.Parameters.AddWithValue("@id_recinto", recinto.Id_recinto);
                    var linhas = cmd.ExecuteNonQuery();

                    if (linhas == 0)
                        throw new Exception("Nenhum registro foi atualizado (verifique o id_recinto)");
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void Delete(int id_recinto)
        {
            try
            {
                string sql = "DELETE FROM recinto WHERE id_recinto = @id_recinto";
                using (var conexao = Conexao.Conectar())
                using (var cmd = new MySqlCommand(sql, conexao))
                {
                    cmd.Parameters.AddWithValue("@id_recinto", id_recinto);
                    var linhasAfetadas = cmd.ExecuteNonQuery();
                    if (linhasAfetadas == 0)
                        throw new Exception("Nenhum registro encontrado com esse ID.");
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public List<Recinto> ListarTodos()
        {
            List<Recinto> recinto = new List<Recinto>();

            try
            {
                string sql = "SELECT * FROM recinto ORDER BY id_recinto";

                using (var conexao = Conexao.Conectar())
                using (var comando = new MySqlCommand(sql, conexao))
                using (MySqlDataReader dr = comando.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        Recinto recintos = new Recinto()
                        {
                            Id_recinto = Convert.ToInt32(dr["id_recinto"]),
                            Tipo = (dr["tipo"].ToString()),
                            capacidade = Convert.ToInt32(dr["capacidade"]),
                            localizacao = dr["localizacao"].ToString()
                        };
                        recinto.Add(recintos);
                    }
                }

                return recinto;
            }
            catch (Exception ex)
            {
                throw new Exception("Erro ao listar os recintos: " + ex.Message);
            }
        }

        public Recinto BuscarID(int id_recinto)
        {
            try
            {
                string sql = "SELECT * FROM recinto WHERE id_recinto = @id_recinto";

                using (var conexao = Conexao.Conectar())
                using (var cmd = new MySqlCommand(sql, conexao))
                {
                    cmd.Parameters.AddWithValue("@id_recinto", id_recinto);

                    using (MySqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.Read())
                        {
                            Recinto recinto = new Recinto();

                            recinto.Id_recinto = Convert.ToInt32(dr["id_recinto"]);
                            recinto.Tipo = (dr["tipo"].ToString());
                            recinto.capacidade = Convert.ToInt32(dr["capacidade"]);
                            recinto.localizacao = dr["localizacao"].ToString();

                            return recinto;
                        }
                        else
                        {
                            throw new Exception("Nenhum recinto encontrado com esse ID.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
