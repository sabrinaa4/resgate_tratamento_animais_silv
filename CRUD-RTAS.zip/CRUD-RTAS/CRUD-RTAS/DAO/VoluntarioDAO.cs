﻿using CRUD_RTAS.DataBase;
using CRUD_RTAS.Interface;
using CRUD_RTAS.Mapeamento;
using MySql.Data.MySqlClient;

namespace CRUD_RTAS.DAO
{
    internal class VoluntarioDAO : IDAO<Voluntario>
    {
        public void Cadastrar(Voluntario voluntario)
        {
            try
            {
                string sql = @"INSERT INTO voluntario (nome, cpf, telefone, area_atuacao) VALUES
                (@nome, @cpf, @telefone, @area_atuacao)";
                using (var conexao = Conexao.Conectar())
                using (var cmd = new MySqlCommand(sql, conexao))
                {
                    cmd.Parameters.AddWithValue("@nome", voluntario.Nome);
                    cmd.Parameters.AddWithValue("@cpf", voluntario.Cpf);
                    cmd.Parameters.AddWithValue("@telefone", voluntario.Telefone);
                    cmd.Parameters.AddWithValue("@area_atuacao", voluntario.Area_atuacao);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void Atualizar(Voluntario voluntario)
        {
            try
            {
                string sql = @"UPDATE voluntario SET nome = @nome, cpf = @cpf, telefone = @telefone,
                area_atuacao = @area_atuacao WHERE id_voluntario = @id_voluntario";
                using (var conexao = Conexao.Conectar())
                using (var cmd = new MySqlCommand(sql, conexao))
                {
                    cmd.Parameters.AddWithValue("@nome", voluntario.Nome);
                    cmd.Parameters.AddWithValue("@cpf", voluntario.Cpf);
                    cmd.Parameters.AddWithValue("@telefone", voluntario.Telefone);
                    cmd.Parameters.AddWithValue("@area_atuacao", voluntario.Area_atuacao);
                    cmd.Parameters.AddWithValue("@id_voluntario", voluntario.Id_voluntario);
                    var linhas = cmd.ExecuteNonQuery();

                    if (linhas == 0)
                        throw new Exception("Nenhum registro foi atualizado (verifique o id_voluntario)");
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void Delete(int id_voluntario)
        {
            try
            {
                string sql = "DELETE FROM voluntario WHERE id_voluntario = @id_voluntario";
                using (var conexao = Conexao.Conectar())
                using (var cmd = new MySqlCommand(sql, conexao))
                {
                    cmd.Parameters.AddWithValue("@id_voluntario", id_voluntario);
                    var linhasAfetadas = cmd.ExecuteNonQuery();
                    if (linhasAfetadas == 0)
                        throw new Exception("Nenhum registro encontrado com esse ID.");
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public List<Voluntario> ListarTodos()
        {
            List<Voluntario> voluntario = new List<Voluntario>();

            try
            {
                string sql = "SELECT * FROM voluntario ORDER BY nome";

                using (var conexao = Conexao.Conectar())
                using (var comando = new MySqlCommand(sql, conexao))
                using (MySqlDataReader dr = comando.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        Voluntario voluntarios = new Voluntario()
                        {
                            Id_voluntario = Convert.ToInt32(dr["id_voluntario"]),
                            Nome = dr["nome"].ToString(),
                            Cpf = dr["cpf"].ToString(),
                            Telefone = dr["telefone"].ToString(),
                            Area_atuacao = dr["area_atuacao"].ToString()
                        };
                        voluntario.Add(voluntarios);
                    }
                }

                return voluntario;
            }
            catch (Exception ex)
            {
                throw new Exception("Erro ao listar os voluntários: " + ex.Message);
            }
        }

        public Voluntario BuscarID(int id_voluntario)
        {
            try
            {
                string sql = "SELECT * FROM voluntario WHERE id_voluntario = @id_voluntario";

                using (var conexao = Conexao.Conectar())
                using (var cmd = new MySqlCommand(sql, conexao))
                {
                    cmd.Parameters.AddWithValue("@id_voluntario", id_voluntario);

                    using (MySqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.Read())
                        {
                            Voluntario voluntario = new Voluntario();

                            voluntario.Id_voluntario = Convert.ToInt32(dr["id_voluntario"]);
                            voluntario.Nome = dr["nome"].ToString();
                            voluntario.Cpf = dr["cpf"].ToString();
                            voluntario.Telefone = dr["telefone"].ToString();
                            voluntario.Area_atuacao = dr["area_atuacao"].ToString();

                            return voluntario;
                        }
                        else
                        {
                            throw new Exception("Nenhum voluntário encontrado com esse ID.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
