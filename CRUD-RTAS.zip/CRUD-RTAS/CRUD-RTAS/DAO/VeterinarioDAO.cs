﻿using CRUD_RTAS.DataBase;
using CRUD_RTAS.Interface;
using CRUD_RTAS.Mapeamento;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Text;

namespace CRUD_RTAS.DAO
{
    internal class VeterinarioDAO : IDAO<Veterinario>
    {
        public void Atualizar(Veterinario veterinario)
        {
            try
            {
                string sql = @"UPDATE veterinario SET nome = @nome, crmv = @crmv,
                especialidade = @especialidade, telefone = @telefone
                WHERE id_veterinario = @id_veterinario";
                using (var conexao = Conexao.Conectar())
                using (var cmd = new MySqlCommand(sql, conexao))
                {
                    cmd.Parameters.AddWithValue("@nome", veterinario.Nome);
                    cmd.Parameters.AddWithValue("@crmv", veterinario.Crmv);
                    cmd.Parameters.AddWithValue("@especialidade", veterinario.Especialidade);
                    cmd.Parameters.AddWithValue("@telefone", veterinario.Telefone);
                    cmd.Parameters.AddWithValue("@id_veterinario", veterinario.Id_veterinario);
                    var linhas = cmd.ExecuteNonQuery();

                    if (linhas == 0)
                        throw new Exception("Nenhum registro foi atualizado (verifique o id_veterinario).");
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public Veterinario BuscarID(int id_veterinario)
        {
            try
            {
                string sql = "SELECT * FROM veterinario WHERE id_veterinario = @id_veterinario";

                using (var conexao = Conexao.Conectar())
                using (var cmd = new MySqlCommand(sql, conexao))
                {
                    cmd.Parameters.AddWithValue("@id_veterinario", id_veterinario);

                    using (MySqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.Read())
                        {
                            Veterinario veterinario = new Veterinario();

                            veterinario.Id_veterinario = Convert.ToInt32(dr["id_veterinario"]);
                            veterinario.Nome = dr["nome"].ToString();
                            veterinario.Crmv = dr["crmv"].ToString();
                            veterinario.Especialidade = dr["especialidade"].ToString();
                            veterinario.Telefone = dr["telefone"].ToString();

                            return veterinario;
                        }
                        else
                        {
                            throw new Exception("Nenhum veterinário encontrado com esse ID.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        

        public void Cadastrar(Veterinario veterinario)
        {
            try
            {
                string sql = @"INSERT INTO Veterinario (Nome, Crmv, Especialidade, Telefone) VALUES
     (@nome, @crmv, @especialidade, @telefone)";
                using (var conexao = Conexao.Conectar())
                using (var cmd = new MySqlCommand(sql, conexao))
                {
                    cmd.Parameters.AddWithValue("@Nome", veterinario.Nome);
                    cmd.Parameters.AddWithValue("@Crmv", veterinario.Crmv);
                    cmd.Parameters.AddWithValue("@Especialidade", veterinario.Especialidade);
                    cmd.Parameters.AddWithValue("@Telefone", veterinario.Telefone);
                    
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void Delete(int id_veterinario)
        {
            try
            {
                string sql = "DELETE FROM veterinario WHERE id_veterinario = @id_veterinario";
                using (var conexao = Conexao.Conectar())
                using (var cmd = new MySqlCommand(sql, conexao))
                {
                    cmd.Parameters.AddWithValue("@id_veterinario", id_veterinario);
                    var linhasAfetadas = cmd.ExecuteNonQuery();
                    if (linhasAfetadas == 0)
                        throw new Exception("Nenhum registro encontrado com esse ID.");
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public List<Veterinario> ListarTodos()
        {
            List<Veterinario> veterinario = new List<Veterinario>();

            try
            {
                string sql = "SELECT * FROM veterinario ORDER BY nome";

                using (var conexao = Conexao.Conectar())
                using (var comando = new MySqlCommand(sql, conexao))
                using (MySqlDataReader dr = comando.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        Veterinario veterinarios = new Veterinario()
                        {
                            Id_veterinario = Convert.ToInt32(dr["id_veterinario"]),
                            Nome = dr["nome"].ToString(),
                            Crmv = dr["crmv"].ToString(),
                            Especialidade = dr["especialidade"].ToString(),
                            Telefone = dr["telefone"].ToString()
                        };
                        veterinario.Add(veterinarios);
                    }
                }

                return veterinario;
            }
            catch (Exception ex)
            {
                throw new Exception("Erro ao listar os veterinários: " + ex.Message);
            }
        }
    }
}
