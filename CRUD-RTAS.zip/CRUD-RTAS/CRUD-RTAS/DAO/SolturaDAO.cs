﻿using CRUD_RTAS.DataBase;
using CRUD_RTAS.Interface;
using CRUD_RTAS.Mapeamento;
using MySql.Data.MySqlClient;

namespace CRUD_RTAS.DAO
{
    internal class SolturaDAO : IDAO<Soltura>
    {
        public void Cadastrar(Soltura soltura)
        {
            try
            {
                string sql = @"INSERT INTO soltura (observacoes, data_soltura, id_animal_fk, id_veterinario_fk, id_local_soltura_fk) VALUES
                (@observacoes, @data_soltura, @id_animal_fk, @id_veterinario_fk, @id_local_soltura_fk)";
                using (var conexao = Conexao.Conectar())
                using (var cmd = new MySqlCommand(sql, conexao))
                {
                    cmd.Parameters.AddWithValue("@observacoes", soltura.Observacoes);
                    cmd.Parameters.Add("@data_soltura", MySqlDbType.Date).Value = soltura.Data_soltura.ToDateTime(TimeOnly.MinValue);
                    cmd.Parameters.AddWithValue("@id_animal_fk", soltura.Animal.Id_animal);
                    cmd.Parameters.AddWithValue("@id_veterinario_fk", soltura.Veterinario.Id_veterinario);
                    cmd.Parameters.AddWithValue("@id_local_soltura_fk", soltura.Local_soltura.Id_local_soltura);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void Atualizar(Soltura soltura)
        {
            try
            {
                string sql = @"UPDATE soltura SET observacoes = @observacoes, data_soltura = @data_soltura,
                id_animal_fk = @id_animal_fk, id_veterinario_fk = @id_veterinario_fk,
                id_local_soltura_fk = @id_local_soltura_fk WHERE id_soltura = @id_soltura";
                using (var conexao = Conexao.Conectar())
                using (var cmd = new MySqlCommand(sql, conexao))
                {
                    cmd.Parameters.AddWithValue("@observacoes", soltura.Observacoes);
                    cmd.Parameters.Add("@data_soltura", MySqlDbType.Date).Value = soltura.Data_soltura.ToDateTime(TimeOnly.MinValue);
                    cmd.Parameters.AddWithValue("@id_animal_fk", soltura.Animal.Id_animal);
                    cmd.Parameters.AddWithValue("@id_veterinario_fk", soltura.Veterinario.Id_veterinario);
                    cmd.Parameters.AddWithValue("@id_local_soltura_fk", soltura.Local_soltura.Id_local_soltura);
                    cmd.Parameters.AddWithValue("@id_soltura", soltura.Id_soltura);
                    var linhas = cmd.ExecuteNonQuery();

                    if (linhas == 0)
                        throw new Exception("Nenhum registro foi atualizado (verifique o id_soltura)");
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void Delete(int id_soltura)
        {
            try
            {
                string sql = "DELETE FROM soltura WHERE id_soltura = @id_soltura";
                using (var conexao = Conexao.Conectar())
                using (var cmd = new MySqlCommand(sql, conexao))
                {
                    cmd.Parameters.AddWithValue("@id_soltura", id_soltura);
                    var linhasAfetadas = cmd.ExecuteNonQuery();
                    if (linhasAfetadas == 0)
                        throw new Exception("Nenhum registro encontrado com esse ID.");
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public List<Soltura> ListarTodos()
        {
            List<Soltura> soltura = new List<Soltura>();

            try
            {
                string sql = "SELECT * FROM soltura ORDER BY data_soltura DESC";

                using (var conexao = Conexao.Conectar())
                using (var comando = new MySqlCommand(sql, conexao))
                using (MySqlDataReader dr = comando.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        Soltura solturas = new Soltura()
                        {
                            Id_soltura = Convert.ToInt32(dr["id_soltura"]),
                            Observacoes = dr["observacoes"].ToString(),
                            Data_soltura = DateOnly.FromDateTime(Convert.ToDateTime(dr["data_soltura"])),
                            Animal = new Animal() { Id_animal = Convert.ToInt32(dr["id_animal_fk"]) },
                            Veterinario = new Veterinario() { Id_veterinario = Convert.ToInt32(dr["id_veterinario_fk"]) },
                            Local_soltura = new Local_soltura() { Id_local_soltura = Convert.ToInt32(dr["id_local_soltura_fk"]) }
                        };
                        soltura.Add(solturas);
                    }
                }

                return soltura;
            }
            catch (Exception ex)
            {
                throw new Exception("Erro ao listar as solturas: " + ex.Message);
            }
        }

        public Soltura BuscarID(int id_soltura)
        {
            try
            {
                string sql = "SELECT * FROM soltura WHERE id_soltura = @id_soltura";

                using (var conexao = Conexao.Conectar())
                using (var cmd = new MySqlCommand(sql, conexao))
                {
                    cmd.Parameters.AddWithValue("@id_soltura", id_soltura);

                    using (MySqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.Read())
                        {
                            Soltura soltura = new Soltura();

                            soltura.Id_soltura = Convert.ToInt32(dr["id_soltura"]);
                            soltura.Observacoes = dr["observacoes"].ToString();
                            soltura.Data_soltura = DateOnly.FromDateTime(Convert.ToDateTime(dr["data_soltura"]));
                            soltura.Animal = new Animal() { Id_animal = Convert.ToInt32(dr["id_animal_fk"]) };
                            soltura.Veterinario = new Veterinario() { Id_veterinario = Convert.ToInt32(dr["id_veterinario_fk"]) };
                            soltura.Local_soltura = new Local_soltura() { Id_local_soltura = Convert.ToInt32(dr["id_local_soltura_fk"]) };

                            return soltura;
                        }
                        else
                        {
                            throw new Exception("Nenhuma soltura encontrada com esse ID.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
