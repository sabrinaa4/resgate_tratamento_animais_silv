﻿using CRUD_RTAS.DataBase;
using CRUD_RTAS.Interface;
using CRUD_RTAS.Mapeamento;
using MySql.Data.MySqlClient;

namespace CRUD_RTAS.DAO
{
    internal class AnimalDAO : IDAO<Animal>
    {
        public void Cadastrar(Animal animal)
        {
            try
            {
                string sql = @"INSERT INTO animal (nome, sexo, status, origem, data_entrada, id_especie_fk, id_recinto_fk) VALUES
                (@nome, @sexo, @status, @origem, @data_entrada, @id_especie_fk, @id_recinto_fk)";
                using (var conexao = Conexao.Conectar())
                using (var cmd = new MySqlCommand(sql, conexao))
                {
                    cmd.Parameters.AddWithValue("@nome", animal.Nome);
                    cmd.Parameters.AddWithValue("@sexo", animal.Sexo.ToString());
                    cmd.Parameters.AddWithValue("@status", animal.Status.ToString());
                    cmd.Parameters.AddWithValue("@origem", animal.Origem.ToString());
                    cmd.Parameters.Add("@data_entrada", MySqlDbType.Date).Value = animal.DataEntrada.ToDateTime(TimeOnly.MinValue);
                    cmd.Parameters.AddWithValue("@id_especie_fk", animal.Especie.Id_especie);
                    //código usado, que representa que essa fk não éobrigaória.
                    cmd.Parameters.AddWithValue("@id_recinto_fk", (object?)animal.Recinto?.Id_recinto ?? DBNull.Value);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void Atualizar(Animal animal)
        {
            try
            {
                string sql = @"UPDATE animal SET nome = @nome, sexo = @sexo, status = @status, origem = @origem,
                data_entrada = @data_entrada, id_especie_fk = @id_especie_fk, id_recinto_fk = @id_recinto_fk
                WHERE id_animal = @id_animal";
                using (var conexao = Conexao.Conectar())
                using (var cmd = new MySqlCommand(sql, conexao))
                {
                    cmd.Parameters.AddWithValue("@nome", animal.Nome);
                    cmd.Parameters.AddWithValue("@sexo", animal.Sexo.ToString());
                    cmd.Parameters.AddWithValue("@status", animal.Status.ToString());
                    cmd.Parameters.AddWithValue("@origem", animal.Origem.ToString());
                    cmd.Parameters.Add("@data_entrada", MySqlDbType.Date).Value = animal.DataEntrada.ToDateTime(TimeOnly.MinValue);
                    cmd.Parameters.AddWithValue("@id_especie_fk", animal.Especie.Id_especie);
                    cmd.Parameters.AddWithValue("@id_recinto_fk", (object?)animal.Recinto?.Id_recinto ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@id_animal", animal.Id_animal);
                    var linhas = cmd.ExecuteNonQuery();

                    if (linhas == 0)
                        throw new Exception("Nenhum registro foi atualizado (verifique o id_animal)");
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void Delete(int id_animal)
        {
            try
            {
                string sql = "DELETE FROM animal WHERE id_animal = @id_animal";
                using (var conexao = Conexao.Conectar())
                using (var cmd = new MySqlCommand(sql, conexao))
                {
                    cmd.Parameters.AddWithValue("@id_animal", id_animal);
                    var linhasAfetadas = cmd.ExecuteNonQuery();
                    if (linhasAfetadas == 0)
                        throw new Exception("Nenhum registro encontrado com esse ID.");
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public List<Animal> ListarTodos()
        {
            List<Animal> animal = new List<Animal>();

            try
            {
                string sql = "SELECT * FROM animal ORDER BY nome";

                using (var conexao = Conexao.Conectar())
                using (var comando = new MySqlCommand(sql, conexao))
                using (MySqlDataReader dr = comando.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        Animal animais = new Animal()
                        {
                            Id_animal = Convert.ToInt32(dr["id_animal"]),
                            Nome = dr["nome"].ToString(),
                            Sexo = dr["sexo"].ToString(),
                            Status = dr["status"].ToString(),
                            Origem = dr["origem"].ToString(),
                            DataEntrada = DateOnly.FromDateTime(Convert.ToDateTime(dr["data_entrada"])),
                            Especie = new Especie() { Id_especie = Convert.ToInt32(dr["id_especie_fk"]) }
                        };

                        if (dr["id_recinto_fk"] != DBNull.Value)
                            animais.Recinto = new Recinto() { Id_recinto = Convert.ToInt32(dr["id_recinto_fk"]) };

                        animal.Add(animais);
                    }
                }

                return animal;
            }
            catch (Exception ex)
            {
                throw new Exception("Erro ao listar os animais: " + ex.Message);
            }
        }

        public Animal BuscarID(int id_animal)
        {
            try
            {
                string sql = "SELECT * FROM animal WHERE id_animal = @id_animal";

                using (var conexao = Conexao.Conectar())
                using (var cmd = new MySqlCommand(sql, conexao))
                {
                    cmd.Parameters.AddWithValue("@id_animal", id_animal);

                    using (MySqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.Read())
                        {
                            Animal animal = new Animal();

                            animal.Id_animal = Convert.ToInt32(dr["id_animal"]);
                            animal.Nome = dr["nome"].ToString();
                            animal.Sexo = dr["sexo"].ToString();
                            animal.Status = dr["status"].ToString();
                            animal.Origem = dr["origem"].ToString();
                            animal.DataEntrada = DateOnly.FromDateTime(Convert.ToDateTime(dr["data_entrada"]));
                            animal.Especie = new Especie() { Id_especie = Convert.ToInt32(dr["id_especie_fk"]) };

                            if (dr["id_recinto_fk"] != DBNull.Value)
                                animal.Recinto = new Recinto() { Id_recinto = Convert.ToInt32(dr["id_recinto_fk"]) };

                            return animal;
                        }
                        else
                        {
                            throw new Exception("Nenhum animal encontrado com esse ID.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
