﻿using CRUD_RTAS.DataBase;
using CRUD_RTAS.Interface;
using CRUD_RTAS.Mapeamento;
using MySql.Data.MySqlClient;
using static CRUD_RTAS.Mapeamento.Local_soltura;

namespace CRUD_RTAS.DAO
{
    internal class Local_solturaDAO : IDAO<Local_soltura>
    {
        public void Cadastrar(Local_soltura local_soltura)
        {
            try
            {
                string sql = @"INSERT INTO local_soltura (nome, bioma, cidade, estado) VALUES
                (@nome, @bioma, @cidade, @estado)";
                using (var conexao = Conexao.Conectar())
                using (var cmd = new MySqlCommand(sql, conexao))
                {
                    cmd.Parameters.AddWithValue("@nome", local_soltura.nome);
                    cmd.Parameters.AddWithValue("@bioma", local_soltura.Bioma);
                    cmd.Parameters.AddWithValue("@cidade", local_soltura.Cidade);
                    cmd.Parameters.AddWithValue("@estado", local_soltura.Estado);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void Atualizar(Local_soltura local_soltura)
        {
            try
            {
                string sql = @"UPDATE local_soltura SET nome = @nome, bioma = @bioma, cidade = @cidade,
                estado = @estado WHERE id_local_soltura = @id_local_soltura";
                using (var conexao = Conexao.Conectar())
                using (var cmd = new MySqlCommand(sql, conexao))
                {
                    cmd.Parameters.AddWithValue("@nome", local_soltura.nome);
                    cmd.Parameters.AddWithValue("@bioma", local_soltura.Bioma);
                    cmd.Parameters.AddWithValue("@cidade", local_soltura.Cidade);
                    cmd.Parameters.AddWithValue("@estado", local_soltura.Estado);
                    cmd.Parameters.AddWithValue("@id_local_soltura", local_soltura.Id_local_soltura);
                    var linhas = cmd.ExecuteNonQuery();

                    if (linhas == 0)
                        throw new Exception("Nenhum registro foi atualizado (verifique o id_local_soltura)");
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void Delete(int id_local_soltura)
        {
            try
            {
                string sql = "DELETE FROM local_soltura WHERE id_local_soltura = @id_local_soltura";
                using (var conexao = Conexao.Conectar())
                using (var cmd = new MySqlCommand(sql, conexao))
                {
                    cmd.Parameters.AddWithValue("@id_local_soltura", id_local_soltura);
                    var linhasAfetadas = cmd.ExecuteNonQuery();
                    if (linhasAfetadas == 0)
                        throw new Exception("Nenhum registro encontrado com esse ID.");
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public List<Local_soltura> ListarTodos()
        {
            List<Local_soltura> local_soltura = new List<Local_soltura>();

            try
            {
                string sql = "SELECT * FROM local_soltura ORDER BY nome";

                using (var conexao = Conexao.Conectar())
                using (var comando = new MySqlCommand(sql, conexao))
                using (MySqlDataReader dr = comando.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        Local_soltura locais = new Local_soltura()
                        {
                            Id_local_soltura = Convert.ToInt32(dr["id_local_soltura"]),
                            nome = dr["nome"].ToString(),
                            Bioma = (dr["bioma"].ToString()),
                            Cidade = dr["cidade"].ToString(),
                            Estado = dr["estado"].ToString()
                        };
                        local_soltura.Add(locais);
                    }
                }

                return local_soltura;
            }
            catch (Exception ex)
            {
                throw new Exception("Erro ao listar os locais de soltura: " + ex.Message);
            }
        }

        public Local_soltura BuscarID(int id_local_soltura)
        {
            try
            {
                string sql = "SELECT * FROM local_soltura WHERE id_local_soltura = @id_local_soltura";

                using (var conexao = Conexao.Conectar())
                using (var cmd = new MySqlCommand(sql, conexao))
                {
                    cmd.Parameters.AddWithValue("@id_local_soltura", id_local_soltura);

                    using (MySqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.Read())
                        {
                            Local_soltura local_soltura = new Local_soltura();

                            local_soltura.Id_local_soltura = Convert.ToInt32(dr["id_local_soltura"]);
                            local_soltura.nome = dr["nome"].ToString();
                            local_soltura.Bioma = (dr["bioma"].ToString());
                            local_soltura.Cidade = dr["cidade"].ToString();
                            local_soltura.Estado = dr["estado"].ToString();

                            return local_soltura;
                        }
                        else
                        {
                            throw new Exception("Nenhum local de soltura encontrado com esse ID.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
