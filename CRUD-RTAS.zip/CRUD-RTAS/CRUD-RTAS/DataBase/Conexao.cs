﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Text;

namespace CRUD_RTAS.DataBase
{
    internal static class Conexao
    {
        private const string strconexao =
            "server=localhost;uid=root;pwd=root;database=resgate_tratamento_animais_silv;port=3306";

        public static MySqlConnection Conectar()
        {
            MySqlConnection conexao = new MySqlConnection(strconexao);

            try
            {
                conexao.Open();
                //Console.WriteLine("Conectado...");
                return conexao;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
    }
}
